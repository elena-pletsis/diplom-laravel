 

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($pageTitle); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php if(session('message')): ?>
	    <div class="alert alert-success">
	        <?php echo e(session('message')); ?>

	    </div>
	<?php endif; ?>
	
	<form action="/admin/brand/<?php echo e($brand->id); ?>" method="POST">
		<input type="hidden" name="_method" value="PUT">
		<?php echo e(csrf_field()); ?>


		<div class="form-group">
			<label for="title">Название:</label>
			<input type="text" class="form-control" id="title" name="title" value="<?php echo e($brand->title); ?>">
		</div>
		<div class="form-group">
			<label for="slug">Слаг:</label>
			<input type="text" class="form-control" id="slug" name="slug" value="<?php echo e($brand->slug); ?>">
		</div>
		<div class="input-group">
		   <span class="input-group-btn">
		     <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
		       <i class="fa fa-picture-o"></i> Выбрать изображение
		     </a>
		   </span>
		   <input id="thumbnail" class="form-control" type="hidden" name="filepath" value="<?php echo e($brand->img); ?>">
		 </div>
 		<img src="<?php echo e($brand->img); ?>" id="holder" style="margin-top:15px;max-height:100px;">
 		<?php if($brand->img): ?>
 			<div class="checkbox">
 				<label><input type="checkbox" class="remove-img" name="remove">Удалить изображение</label>
 			</div>
 		<?php endif; ?>
 		<div class="form-group">
			<label for="description">Описание:</label>
			<textarea class="form-control" id="description" name="description" ><?php echo e($brand->description); ?></textarea>		
		</div>
		<button class="btn btn-primary">Сохранить</button>		
	</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="/vendor/laravel-filemanager/js/lfm.js"></script>
<script>
	$('#lfm').filemanager('image');

	$(document).ready( function () {
    	$('#roles').select2();
	} );

	$('#thumbnail').change(function(){
		if( $(this).val() ){
			$('.remove-img').prop('checked', false)
		}
	});
</script>>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/admin/brand/edit.blade.php ENDPATH**/ ?>