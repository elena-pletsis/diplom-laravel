<?php $__env->startSection('content'); ?>
<div class="container">
	<?php if(session('message')): ?>
	    <div class="alert alert-success">
	        <?php echo e(session('message')); ?>

	    </div>
	<?php endif; ?>

    <div class="row">          
      <div class="col-md-10 mt-4 reviews-wrapper">
        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="d-flex justify-content-between">
            <strong><a href="/product/<?php echo e($review->product->slug); ?>"><?php echo e($review->product->title); ?></a></strong>
            <small><?php echo e($review->created_at); ?></small>
          </div>
          <div class="mt-3">
            <p class="pl-5 mt-1"><?php echo e($review->review_text); ?></p>
          </div>
          <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="col-md-2"></div>
    </div>
    <div class="d-flex justify-content-center"><?php echo e($reviews->links('vendor.pagination.bootstrap-4')); ?> </div>	

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	(function($){
        $(document).ready(function(){
	        
        });
    })(jQuery);  
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/web/profile/reviews.blade.php ENDPATH**/ ?>