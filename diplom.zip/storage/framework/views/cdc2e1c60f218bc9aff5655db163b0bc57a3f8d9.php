 

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($pageTitle); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php if(session('message')): ?>
	    <div class="alert alert-success">
	        <?php echo e(session('message')); ?>

	    </div>
	<?php endif; ?>
	<table id="table">
		<thead>
			<tr>
				<th>#</th>
				<th>Имя фамилия</th>
				<th>Email</th>
				<th>Адрес</th>
				<th>Номер телефона</th>
				<th>Роли</th>
				<th>Член клуба "Мокрый нос"</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				
				<tr data-id="<?php echo e($user->id); ?>">
					<td><?php echo e($loop->iteration); ?></td>
					<td class="user-name">
						<?php echo e($user->full_name); ?>

						<div class="user-edit">
							<a href="/admin/users/<?php echo e($user->id); ?>/edit" class="btn-link">Редактировать</a>
							<form action="/admin/users/<?php echo e($user->id); ?>" method="POST">
								<input type="hidden" name="_method" value="DELETE">
								<?php echo e(csrf_field()); ?>

								<button class="delete btn-link" style="width: 80px">Удалить</button>
							</form>
						</div>
					</td>
					<td><?php echo e($user->email); ?></td>
					<td><?php echo e($user->address); ?></td>
					<td><?php echo e($user->phone); ?></td>
					<td><?php echo e($user->roles->implode('name', ', ')); ?></td> 
					
					<td>
						<i class="edit-club-member fa-lg fa fa-chevron-down <?php echo e($user->club_member?'text-danger':'text-success'); ?>"></i>	
					</td>
				</tr>
				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
		</tbody>
	</table>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	(function($){
        $(document).ready(function(){
	        $('#table').DataTable({
	        	// drawCallback, функция, которая вызывается каждый раз, когда DataTables выполняет отрисовку.
	        	 "drawCallback": function( settings ) {  
        			$( ".user-name" )
			  		.on( "mouseenter", function() {
			  			$(this).find('.user-edit').addClass('visible');
					})
					.on( "mouseleave", function() {
			  			$(this).find('.user-edit').removeClass('visible');
					});
    			}
	        });
        });
    })(jQuery);  
</script>

<?php $__env->stopSection(); ?>

	
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/admin/users/index.blade.php ENDPATH**/ ?>