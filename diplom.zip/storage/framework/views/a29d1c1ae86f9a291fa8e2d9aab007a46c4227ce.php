<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Сменить пароль</div>

                <div class="card-body">

                    <form method="POST" action="/profile/updatePassword">
                        <?php echo csrf_field(); ?>

                        

                        <div class="form-group row">
                            <label for="currentPassword" class="col-md-4 col-form-label text-md-right">Текущий пароль</label>

                            <div class="col-md-6">
                                <input id="currentPassword" type="password" class="form-control <?php if ($errors->has('currentPassword')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('currentPassword'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="currentPassword" required>

                                <?php if ($errors->has('currentPassword')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('currentPassword'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="newPassword" class="col-md-4 col-form-label text-md-right">Новый пароль</label>
							
                            <div class="col-md-6">
                                <input id="newPassword" type="password" class="form-control <?php if ($errors->has('newPassword')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('newPassword'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="newPassword" required pattern="^\S{8,}$" onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Must have at least 8 characters' : ''); if(this.checkValidity()) form.passwordConfirm.pattern = this.value;">

                                <?php if ($errors->has('newPassword')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('newPassword'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="passwordConfirm" class="col-md-4 col-form-label text-md-right">Повторить новый пароль</label>

                            <div class="col-md-6">
                                <input id="passwordConfirm" type="password" class="form-control" name="passwordConfirmation" required autocomplete="newPassword" pattern="^\S{8,}$" onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Please enter the same Password as above' : '');">
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-change-password">
                                    Сохранить
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
	(function($){
        $(document).ready(function(){

			
        });
    })(jQuery);  
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/web/profile/changePassword.blade.php ENDPATH**/ ?>