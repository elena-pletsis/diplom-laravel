 

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($pageTitle); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<table id="table" class="table">
		<thead>
			<tr>
				<th></th>
				<th>Id</th>
				<th>Название</th>
				<th>Изображение</th>
				<th>Родительская категория</th>
			</tr>
		</thead>
		<tbody>
			
			<?php $__currentLoopData = $mainCategoriesProvider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr class="success">
					<td class="details-control main-category"></td>
					<td><?php echo e($mainCategory->id); ?></td>
					<td class="category-title">
						<?php echo e($mainCategory->title); ?>

						<div class="category-edit">
							<a href="/admin/category/<?php echo e($mainCategory->id); ?>/edit" class="btn-link">Редактировать</a>
							<form action="/admin/category/<?php echo e($mainCategory->id); ?>" method="POST">
								<input type="hidden" name="_method" value="DELETE">
								<?php echo e(csrf_field()); ?>

								<button class="delete btn-link" style="width: 80px">Удалить</button>
							</form>
						</div>
					</td>
					<td><img src="<?php echo e($mainCategory->img); ?>" alt=""></td>
					<td><?php echo e($mainCategory->parent?$mainCategory->parent->title:""); ?></td>
				</tr>
				<?php $__currentLoopData = $mainCategory->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $titleCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td class="details-control"></td>
						<td><?php echo e($titleCategory->id); ?></td>
						<td class="category-title">
							<?php echo e($titleCategory->title); ?>

							<div class="category-edit">
								<a href="/admin/category/<?php echo e($titleCategory->id); ?>/edit" class="btn-link">Редактировать</a>
								<form action="/admin/category/<?php echo e($titleCategory->id); ?>" method="POST">
									<input type="hidden" name="_method" value="DELETE">
									<?php echo e(csrf_field()); ?>

									<button class="delete btn-link" style="width: 80px">Удалить</button>
								</form>
							</div>
						</td>
						<td class="text-center"><img src="<?php echo e($titleCategory->img); ?>" alt="" style="width: 80px; height: 80px;"></td>
						<td><?php echo e($titleCategory->parent?$titleCategory->parent->title:""); ?></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
		</tbody>
		<tfoot>
			<tr>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
				<th></th>				
			</tr>
		</tfoot>
	</table> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	(function($){
        $(document).ready(function(){
// https://datatables.net/blog/2017-03-31 //datatables child rows ajax
	        function format ( rowData ) {
	        	// console.log(rowData);
    			var div = $('<div/>')
        			.addClass( 'loading' )
        			.text( 'Loading...' );
 
			    $.ajax( {
			        url: '/admin/title-categories',
			        type: "POST",
			        data: {
			        	categoryId: rowData.Id
			        },
			        dataType: 'json',
			        success: function ( json ) {
			        	// console.log(json);
			        	var subCategoryTable = 
			        	`<table class="dataTable inner-table table">`;			
						$.each(json, function (index, titleCategory) {

							//dd($cat);
							subCategoryTable += 
					        `<tr>
					        <td class="success"></td>
					        <td class="success">${titleCategory.id}</td>
							<td class="category-title success">${titleCategory.title}
								<div class="category-edit">
									<a href="/admin/category/${titleCategory.id}/edit" class="btn-link">Edit</a>
									<form action="/admin/category/${titleCategory.id}" method="POST">
										<input type="hidden" name="_method" value="DELETE">
										<?php echo e(csrf_field()); ?>

										<button class="delete btn-link" style="width: 80px">Delete</button>
									</form>
								</div>
							</td>
							<td class="success"><img src="${titleCategory.img}" alt="" style="width: 80px; height: 80px;"></td>
							<td class="success"></td>						
							</tr>`
					    });

				 		subCategoryTable += '</table>';

			            div
			                .html( subCategoryTable )
			                .removeClass( 'loading' );
			        }
			    } );
 
    			return div;
			}


	        var table = $('#table').DataTable( {

	        	"drawCallback": function( settings ) {
        			$( ".category-title" )
			  		.on( "mouseenter", function() {
			  			$(this).find('.category-edit').addClass('visible');
					})
					.on( "mouseleave", function() {
			  			$(this).find('.category-edit').removeClass('visible');
					});
    			},

		        "columns": [
		            {
		                "className":      'details-control',
		                "orderable":      false,
		                "data":           null,
		                "defaultContent": ''
		            },
		            
		            { "data": "Id" },
		            { "data": "Title" },
		            { "data": "Img" },
		            { "data": "Parent category" }
		        ],
		        "order": []
		        // "order": [[1, 'asc']],	   

		    } );
			     
		    // Add event listener for opening and closing details
		    $('#table tbody').on('click', 'td.details-control', function () {
		    	if ($(this).hasClass('main-category'))
		    		return;
		        var tr = $(this).closest('tr');
		        var row = table.row( tr );

		        if ( row.child.isShown() ) {
		            // This row is already open - close it
		            row.child.hide();
		            tr.removeClass('shown');
		        }
		        else {
		            // Open this row
		            row.child( format(row.data()) ).show();
		            tr.addClass('shown');
		        }
		    } );

		    $('body').on('mouseenter', '.inner-table td.category-title', function () {
		    	$(this).find('.category-edit').addClass('visible');
		    } );

		    $('body').on('mouseleave', '.inner-table td.category-title', function () {
		    	$(this).find('.category-edit').removeClass('visible');
		    } );

        });
    })(jQuery);  
</script>

<?php $__env->stopSection(); ?>










 
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/admin/category/index.blade.php ENDPATH**/ ?>