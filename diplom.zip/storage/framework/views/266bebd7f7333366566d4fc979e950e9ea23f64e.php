 

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($pageTitle); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php if(session('message')): ?>
	    <div class="alert alert-success">
	        <?php echo e(session('message')); ?>

	    </div>
	<?php endif; ?>

	<form action="/admin/product" method="POST">
		<?php echo e(csrf_field()); ?>

		<div class="form-group">
			<label for="title">Название:</label>
			<input type="text" class="form-control" id="title" name="title" value="<?php echo e(old('title')); ?>" required="required">
		</div>
		<div class="form-group">
			<label for="price">Цена:</label>
			<input type="text" class="form-control" id="price" name="price" value="<?php echo e(old('price')); ?>" required="required">
		</div>	
		<div class="form-group">
			<label for="old_price">Старая цена:</label>
			<input type="text" class="form-control" id="old_price" name="old_price" value="<?php echo e(old('old_price')); ?>">
		</div>
		<div class="form-group">
			<label for="package">Упаковка:</label>
			<input type="text" class="form-control" id="package" name="package" value="<?php echo e(old('package')); ?>">
		</div>		
		<div class="form-group">
			<label for="quantity">Количество на складе:</label>
			<input type="text" class="form-control" id="quantity" name="quantity" value="<?php echo e(old('quantity')); ?>" required="required">
		</div>

		<div class="input-group">
		   <span class="input-group-btn">
		     <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
		       <i class="fa fa-picture-o"></i> Выбрать изображение
		     </a>
		   </span>
		   <input id="thumbnail" class="form-control" type="text" name="filepath">
		 </div>
 		<img id="holder" style="margin-top:15px;max-height:100px;">

 		<div class="form-group">
			<label for="description">Описание:</label>
			<textarea class="form-control" id="description" name="description" ><?php echo e(old('description')); ?></textarea>
		</div>
		<div class="checkbox">
 			<label><input type="checkbox" name="status" checked="checked">Статус (в продаже)</label>
 		</div>
		<div class="checkbox">
 			<label><input type="checkbox" name="hit">Хит продукт</label>
 		</div>

 		<div class="form-group">
			<label for="parentId">Категория:</label>
			<select class="form-control" id="parentId" name="parentId">
				<option value="0"></option>
					<?php $__currentLoopData = $mainCategoriesProvider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <?php if($mainCategory->children): ?>
				            <?php $__currentLoopData = $mainCategory->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $titleCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	            
				                    <?php $__currentLoopData = $titleCategory->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                    	<option value="<?php echo e($subCategory->id); ?>"><?php echo e($subCategory->title); ?></option>
				                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        <?php endif; ?>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<div class="form-group">
			<label for="parentId">Бренд:</label>
			<select class="form-control" id="brand" name="brand">
				<option value="0"></option> 
				<?php $__currentLoopData = $brandsProvider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($brand->id); ?>"><?php echo e($brand->title); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>

		<button class="btn btn-primary">Сохранить</button>
	</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="/vendor/laravel-filemanager/js/lfm.js"></script>
<script src="//cdn.ckeditor.com/4.6.2/standard/ckeditor.js"></script>
<script>
 $('#lfm').filemanager('image');
 $('#lfm1').filemanager('image');
 $('#lfm2').filemanager('image');
  var options = {
    filebrowserImageBrowseUrl: '/laravel-filemanager?type=Images',
    filebrowserImageUploadUrl: '/laravel-filemanager/upload?type=Images&_token=',
    filebrowserBrowseUrl: '/laravel-filemanager?type=Files',
    filebrowserUploadUrl: '/laravel-filemanager/upload?type=Files&_token='
  };
 CKEDITOR.replace('description', options);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/admin/product/create.blade.php ENDPATH**/ ?>