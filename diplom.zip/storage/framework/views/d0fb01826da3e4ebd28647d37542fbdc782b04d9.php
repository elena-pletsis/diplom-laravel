 

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($pageTitle); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php if(session('message')): ?>
		    <div class="alert alert-success">
		        <?php echo e(session('message')); ?>

		    </div>
	<?php endif; ?>
	<form action="/admin/discount" method="POST">
		<?php echo csrf_field(); ?>
		<div class="form-group">
			<label for="name">Name:</label>
			<input type="text" class="form-control" id="name" name="name">
		</div>
		<div class="form-group">
			<label for="discount">Discount:</label>
			<input type="text" class="form-control" id="discount" name="discount">
		</div>		
		
		<button class="btn btn-primary">Save</button>
	</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	// $(document).ready( function () {
 //    	$('#roles').select2();
	// } );
	// $(document).ready( function () {
 //    	$('#table').DataTable();
	// } );
</script>>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/admin/discount/create.blade.php ENDPATH**/ ?>