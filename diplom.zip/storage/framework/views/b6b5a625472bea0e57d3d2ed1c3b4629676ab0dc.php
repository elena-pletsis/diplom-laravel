 

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($pageTitle); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php if(session('message')): ?>
	    <div class="alert alert-success">
	        <?php echo e(session('message')); ?>

	    </div>
	<?php endif; ?>
	<table id="table">
		<thead>
			<tr>
				<th>№</th>
				<th>Название</th>
				<th>Изображение</th>
				<th>Описание</th>
			</tr>
		</thead>
		<tbody>

			<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($loop->iteration); ?></td>
					<td class="brand-title">
						<?php echo e($brand->title); ?>

						<div class="brand-edit">
							<a href="/admin/brand/<?php echo e($brand->id); ?>/edit" class="btn-link">Редактировать</a>
							<form action="/admin/brand/<?php echo e($brand->id); ?>" method="POST">
								<input type="hidden" name="_method" value="DELETE">
								<?php echo e(csrf_field()); ?>

								<button class="delete btn-link" style="width: 80px">Удалить</button>
							</form>
						</div>
					</td>
					<td><img src="<?php echo e($brand->img); ?>" alt="" style="width: 100px"></td>
					<td><?php echo e($brand->description); ?></td>
				</tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
		</tbody>
	</table>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	(function($){
        $(document).ready(function(){
	        $('#table').DataTable({
	        	 "drawCallback": function( settings ) {
        			$( ".brand-title" )
			  		.on( "mouseenter", function() {
			  			$(this).find('.brand-edit').addClass('visible');
					})
					.on( "mouseleave", function() {
			  			$(this).find('.brand-edit').removeClass('visible');
					});
    			}
	        });
        });
    })(jQuery);  
</script>

<?php $__env->stopSection(); ?>
	
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/admin/brand/index.blade.php ENDPATH**/ ?>