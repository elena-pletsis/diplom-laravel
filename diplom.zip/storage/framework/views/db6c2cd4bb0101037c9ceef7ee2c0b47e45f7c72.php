 

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($pageTitle); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php if(session('message')): ?>
	    <div class="alert alert-success">
	        <?php echo e(session('message')); ?>

	    </div>
	<?php endif; ?>
	<table id="table">
		<thead>
			<tr>
				<th>Id</th>
				<th>id товара</th>
				<th>Название товара</th>
				<th>id пользователя</th>
				<th>User name</th>
				<th>Text</th>				
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($review->id); ?></td>
					<td><?php echo e($review->product_id); ?></td>
					<td><a href="/admin/review/product/<?php echo e($review->product_id); ?>"><?php echo e($review->product->title); ?></a></td>
					
					<td><?php echo e($review->user_id); ?></td> 
					<td><a href="/admin/review/user/<?php echo e($review->user_id); ?>"><?php echo e($review->user_name); ?></a></td> 
					
					<td><?php echo e($review->review_text); ?></td>								
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
		</tbody>
	</table>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	(function($){
        $(document).ready(function(){
	        $('#table').DataTable({


	        });
        });
    })(jQuery);  
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/admin/review/index.blade.php ENDPATH**/ ?>