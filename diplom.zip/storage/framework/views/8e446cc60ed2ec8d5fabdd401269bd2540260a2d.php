<?php $__env->startSection('content'); ?>
    <!--products-starts-->
    
  <div class="products"> 
    <div class="container">
      <div class="products-top">
        <div class="row">          
          <div class="col-md-9 products-left">
            <div class="product-one row">
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 product-left p-left">
                  <div class="product-main simpleCart_shelfItem">
                    <a href="/product/<?php echo e($product->slug); ?>" class="mask"><img class="img-fluid zoom-img" src="<?php echo e($product->img); ?>" alt="" /></a>
                    <div class="product-bottom">
                      <h3><a href="/product/<?php echo e($product->slug); ?>"><?php echo e($product->title); ?></a></h3>
                      <h4>
                        <a class="add-to-cart-link" href="#" data-id="<?php echo e($product->id); ?>"><i class="fas fa-cart-plus"></i></a>
                        <span class="item_price">
                          <?php if($product->old_price): ?>
                            <small><del><?php echo e($product->old_price); ?></del></small>
                        <?php endif; ?>
                        <?php echo e($product->price); ?> грн.</span>
                      </h4>
                      <?php if(Auth::user()): ?> 
                        
                          <?php if($wishProductsProvider->contains('product_id', $product->id)): ?>
                              <a href="" class="wish-list" data-user_id="<?php echo e(Auth::user()->id); ?>" data-product_id="<?php echo e($product->id); ?>"> <i class="fa-lg fas fa-heart"></i><span class="hidden">Добавить в список желаний</span></a> 
                          <?php else: ?>
                              <a href="" class="wish-list" data-user_id="<?php echo e(Auth::user()->id); ?>" data-product_id="<?php echo e($product->id); ?>"> <i class="fa-lg far fa-heart"></i><span>Добавить в список желаний</span></a> 
                          <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <?php if($product->old_price): ?>
                        <div class="srch">
                            <span><?php echo e(round(($product->old_price-$product->price)*100/$product->old_price, 0)); ?>%</span>
                        </div>
                    <?php endif; ?> 
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <div class="clearfix"></div>            
            </div>

          </div>  
          <div class="col-md-3 products-right">
            <div class="w_sidebar">
              <form action="/filtered-products" method="GET">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="titleCategory" value="<?php echo e($titleCategory->id); ?>">
                <section class="sky-form">
                  <h4>Категории</h4>
                  <div class="row1 scroll-pane">
                    <div class="col">
                      
                      <label><i></i><?php echo e($titleCategory->title); ?></label>
                    </div>
                    <div class="col">               
                      <?php $__currentLoopData = $titleCategory->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="checkbox"><input type="checkbox" name="category[]" value="<?php echo e($category->id); ?>" <?php echo e($category->id == $choosedCategory->id ? 'checked' : ''); ?>><i></i><?php echo e($category->title); ?></label>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  </div>
                </section>
                <section  class="sky-form">
                  <h4>Бренды</h4>
                  <div class="row1 row2 scroll-pane">
                    <div class="col">
                      <?php $__currentLoopData = $brandsProvider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="checkbox"><input type="checkbox" name="brand[]" value="<?php echo e($brand->id); ?>"><i></i><?php echo e($brand->title); ?></label>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  </div>
                </section>
                <section class="sky-form">
                  <h4>Цена</h4>
                  <div class="row no-gutters prices-wrapper">
                    <div class="col-sm-6 d-flex justify-content-center">
                      <input type="text" class="price-filter" name="price_from" pattern="[0-9]+" placeholder="От">
                    </div>
                    <div class="col-sm-6 d-flex justify-content-center">
                      <input type="text" class="price-filter" name="price_to" pattern= "[0-9]+" placeholder="До">
                    </div>
                  </div>
                </section>

                <button type="submit" class="btn filters-button">Применить фильтры</button>
              </form>
            </div>
          </div>
          <div class="clearfix"></div>

        </div>
      </div>
    </div>
     <div class="d-flex justify-content-center"><?php echo e($products->links('vendor.pagination.bootstrap-4')); ?> </div>
  </div>
  <!--product-end-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/web/page/category.blade.php ENDPATH**/ ?>