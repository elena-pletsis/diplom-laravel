 

<?php $__env->startSection('content'); ?>
<div class="container">
	<?php if(session('message')): ?>
	    <div class="alert alert-success">
	        <?php echo e(session('message')); ?>

	    </div>
	<?php endif; ?>

	<div class="row">
		<div class="col-md-10">
			<form action="/profile/edit-profile-details" method="POST">
				<input type="hidden" name="_method" value="PUT">
				<?php echo e(csrf_field()); ?>

				
				<div class="form-group">
					<label for="full_name">Имя фамилия:</label>
					<input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo e($user->full_name); ?>" >
				</div>
				<div class="form-group">
					<label for="email">Email:</label>
					<input type="text" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" >
				</div>
				<div class="form-group">
					<label for="address">Адрес:</label>
					<input type="text" class="form-control" id="address" name="address" value="<?php echo e($user->address); ?>">
				</div>
				<div class="form-group">
					<label for="phone">Телефон:</label>
					<input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($user->phone); ?>">
				</div>
				<button class="btn btn-save-profile-details">Сохранить</button>
			</form>
		</div>
		<div class="col-md-2"></div>
	</div>
</div>		

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	(function($){
        $(document).ready(function(){
	        
        });
    })(jQuery);  
</script>

<?php $__env->stopSection(); ?>

	
<?php echo $__env->make('layouts.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/web/profile/details.blade.php ENDPATH**/ ?>