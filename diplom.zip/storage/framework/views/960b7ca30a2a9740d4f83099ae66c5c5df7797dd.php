 

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($pageTitle); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php if(session('message')): ?>
		    <div class="alert alert-success">
		        <?php echo e(session('message')); ?>

		    </div>
	<?php endif; ?>
	<form action="/admin/users" method="POST">
		<?php echo csrf_field(); ?>
		<div class="form-group">
			<label for="fname">Имя:</label>
			<input type="text" class="form-control" id="fname" name="fname">
		</div>
		<div class="form-group">
			<label for="lname">Фамилия:</label>
			<input type="text" class="form-control" id="lname" name="lname">
		</div>
		<div class="form-group">
			<label for="email">Email:</label>
			<input type="email" class="form-control" id="email" name="email" autocomplete="off">
		</div>
		<div class="form-group">
			<label for="password">Пароль:</label>
			<input type="password" class="form-control" id="password" name="password" autocomplete="off">
		</div>
		<div class="form-group">
			<label for="address">Адрес:</label>
			<input type="text" class="form-control" id="address" name="address">
		</div>
		<div class="form-group">
			<label for="phone">Номер телефона:</label>
			<input type="text" class="form-control" id="phone" name="phone">
		</div>
		<div class="form-group">
			<label for="roles">Роли:</label>
			<select class="form-control" id="roles" name="roles[]" multiple>
				<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<div class="checkbox">
 			<label><input type="checkbox" name="club_member">Член клуба "Мокрый нос"</label>
 		</div>
		
		<button class="btn btn-primary">Сохранить</button>
	</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	$(document).ready( function () {
    	$('#roles').select2();
	} );
	// $(document).ready( function () {
 //    	$('#table').DataTable();
	// } );
</script>>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/admin/users/create.blade.php ENDPATH**/ ?>