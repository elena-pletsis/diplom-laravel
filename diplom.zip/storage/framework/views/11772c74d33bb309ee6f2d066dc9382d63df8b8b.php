<?php $__env->startSection('content'); ?>
<div class="container">
	<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    
    <h1>Оформление заказа</h1>
    <h2 class="mt-3">Ваш заказ:</h2>


<?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row product">
    <div class="col-2">
        <img src="<?php echo e($product['img']); ?>" alt="" class="img-fluid">
    </div>
    <div class="col-10">
       <h4><?php echo e($product['title']); ?></h4> 
       <?php echo e($product['qty']); ?> * <?php echo e($product['price']); ?> =  
       <?php echo e($product['qty'] * $product['price']); ?>       
    </div>    
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="row product">
	<div class="col-2">
		<hr>
		<h5>Итого:</h5>
	</div>
	<div class="col-10">
		<hr>
		Количество товара:  <?php echo e(session('TotalQty')); ?> шт.
		<br>
		Общая сумма: <?php echo e(session('TotalSum')); ?> грн.
		  <?php if(session('Discount') > 0): ?>
		    <br>
		    Ваша скидка: <?php echo e(session('Discount')); ?> %
		    <br>
		    Сумма к оплате: <?php echo e(session('SumToPay')); ?> грн.    
		  <?php endif; ?>          
	</div>
</div>

	<h2 class="mt-3">Ваши данные:</h2>
	<form action="/buy" method="POST">
		<?php echo csrf_field(); ?>
		
		<input type="hidden" name="user_id" class="form-control" <?php if(auth()->guard()->check()): ?> value="<?php echo e(Auth::user()->id); ?>" <?php endif; ?>> 

		<div class="form-group">
			<label for="full_name">Имя фамилия* :</label>
			<input type="text" id="full_name" name="full_name" class="form-control" <?php if(auth()->guard()->check()): ?> value="<?php echo e(Auth::user()->full_name); ?>" <?php endif; ?> required="required">
		</div>
		<div class="form-group">
			<label for="email">Email* :</label>
			<input type="text" id="email" name="email" class="form-control" <?php if(auth()->guard()->check()): ?> value="<?php echo e(Auth::user()->email); ?>" <?php endif; ?> required="required">
		</div>
		<div class="form-group">
			<label for="phone">Номер телефона* (формат ввода: +380501111111) :</label>
			<input type="text" id="phone" name="phone" class="form-control" <?php if(auth()->guard()->check()): ?> value="<?php echo e(Auth::user()->phone); ?>" <?php endif; ?> required="required">
		</div>
		<div id="delivery">
			<div class="delivery-header">
				<p>Доставка:</p>
				<img src="images/NPlogo.png" alt=""/ style="max-width: 11%;">
			</div>
			
			<div class="form-group">
				<label for="npareas">Область* :</label>
				<select class="form-control" id="npareas" name="npareas" required="required">
					<option value="0" selected disabled>Выберите область</option> 
					<?php $__currentLoopData = $npareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($area->Ref); ?>"><?php echo e($area->Description); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group">
				<label for="npcities">Населенный пункт* :</label>
				<select class="form-control" id="npcities" name="npcities" required="required">
					<option value="0" selected disabled>Выберите населенный пункт</option>   
					
				</select>
			</div>
			<div class="form-group">
				<label for="npwarehouses">Отделение* :</label>
				<select class="form-control" id="npwarehouses" name="npwarehouses" required="required">
					<option value="0" selected disabled>Выберите отделение Новой Почты</option>	
												
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="note">Примечание:</label>
			<input type="text" class="form-control" id="note" name="note">
		</div>

		<button class="btn submit-checkout">Оформить заказ</button>
	</form>
    
            
</div>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script>
	(function($){
        $(document).ready(function(){

        	$('#npareas').on('change', function(){
        		//console.log($('#npareas').val());
        		$.ajax({
	        		type: 'POST',
					url: '/choose-nparea',
					dataType: 'json',
					data: {
						areaRef: $('#npareas').val(),
					},
					success: function(response){
						$.each(response, function(key, value) {
						 $("#npcities").append(`<option value="${value.Ref}">${value.SettlementTypeDescriptionRu} ${value.DescriptionRu}</option>`);
						});
					}
        		});
        	});


        	$('#npcities').on('change', function(){
        		$.ajax({
	        		type: 'POST',
					url: '/choose-npcity',
					dataType: 'json',
					data: {
						cityRef: $('#npcities').val(),
					},
					success: function(response){
						$.each(response, function(key, value){
							$("#npwarehouses").append(`<option value="${value.DescriptionRu}">${value.DescriptionRu}</option>`)
						});
					}
        		});
        	});


		});	  
    })(jQuery);  
</script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/web/product/checkout.blade.php ENDPATH**/ ?>