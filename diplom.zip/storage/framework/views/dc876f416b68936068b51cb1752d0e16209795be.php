 

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($pageTitle); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php if(session('message')): ?>
	    <div class="alert alert-success">
	        <?php echo e(session('message')); ?>

	    </div>
	<?php endif; ?>
	
	<form action="/admin/category/<?php echo e($category->id); ?>" method="POST">
		<input type="hidden" name="_method" value="PUT">
		<?php echo e(csrf_field()); ?>


		<div class="form-group">
			<label for="title">Название:</label>
			<input type="text" class="form-control" id="title" name="title" value="<?php echo e($category->title); ?>">
		</div>
		<div class="form-group">
			<label for="slug">Слаг:</label>
			<input type="text" class="form-control" id="slug" name="slug" value="<?php echo e($category->slug); ?>">
		</div>
		
		<div class="form-group">
			<label for="parentId">Родительская категория:</label>
			<select class="form-control" id="parentId" name="parentId">
				<option value="<?php echo e($category->parent? $category->parent->id : ""); ?>"><?php echo e($category->parent ? $category->parent->title : ""); ?></option> 
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
						<option value="<?php echo e($cat->id); ?>"><?php echo e($cat->title); ?></option>
					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<div class="input-group">
		   <span class="input-group-btn">
		     <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
		       <i class="fa fa-picture-o"></i> Выбрать изображение
		     </a>
		   </span>
		   <input id="thumbnail" class="form-control" type="hidden" name="filepath" value="<?php echo e($category->img); ?>">
		 </div>
 		<img src="<?php echo e($category->img); ?>" id="holder" style="margin-top:15px;max-height:100px;">
 		<?php if($category->img): ?>
 			<div class="checkbox">
 				<label><input type="checkbox" class="remove-img" name="remove">Удалить изображение</label>
 			</div>
 		<?php endif; ?>
		<button class="btn btn-primary">Сохранить</button>		
	</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="/vendor/laravel-filemanager/js/lfm.js"></script>
<script>
	$('#lfm').filemanager('image');

	$(document).ready( function () {
    	$('#roles').select2();
	} );

	// $('.remove-img').click(function(){
	// 	if( $(this).prop('checked') ){
	// 		$('#thumbnail').val('');
	// 		$('#holder').attr('src', '');
	// 	}
	// });

	$('#thumbnail').change(function(){
		if( $(this).val() ){
			$('.remove-img').prop('checked', false)
		}
	});
</script>>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>