Получено новое письмо от : <?php echo e($user_full_name); ?>

<p>
ФИО: <?php echo e($user_full_name); ?>

</p>
<p>
Номер телефона: <?php echo e($user_phone); ?>

</p>
<p>
Email: <?php echo e($user_email); ?>

</p>
<p>
Текст сообщения: <?php echo e($user_message); ?>

</p><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/emails/contact.blade.php ENDPATH**/ ?>