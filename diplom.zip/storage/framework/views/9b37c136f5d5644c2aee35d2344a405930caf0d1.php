 

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($pageTitle); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php if(session('message')): ?>
	    <div class="alert alert-success">
	        <?php echo e(session('message')); ?>

	    </div>
	<?php endif; ?>
	<table id="table">
		<thead>
			<tr>
				<th>id товара</th>
				<th>Название:</th>
				<th>Изображение:</th>


				<th>Цена:</th>
				<th>Старая цена:</th>
				<th>Упаковка:</th>
				<th>Количество на складе:</th>
				<th>Статус (в продаже):</th>
				<th>Хит продукт:</th>				
				<th>Категория:</th>
				<th>Бренд:</th>

			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr data-id="<?php echo e($product->id); ?>">
					<td><?php echo e($product->id); ?></td>

					<td class="product-title">
						<?php echo e($product->title); ?>

						<div class="product-edit">
							<a href="/admin/product/<?php echo e($product->id); ?>/edit" class="btn-link">Редактировать</a>
							<a href="#" class="btn-link delete-product">Удалить</a>
						</div>
					</td>
					<td style="text-align: center;"><img src="<?php echo e($product->img); ?>" alt="" style="max-width: 100%; max-height: 100px;"></td>


					<td><?php echo e($product->price); ?></td>
					<td><?php echo e($product->old_price); ?></td>
					<td><?php echo e($product->package); ?></td>
					<td><?php echo e($product->quantity); ?></td>
					<td>

						<i class="edit-status fa-lg fa fa-chevron-down <?php echo e($product->status ? 'text-success' : 'text-danger'); ?>"></i>	
					</td>					
					<td>
						<i class="edit-hit fa-lg fa fa-chevron-down <?php echo e($product->hit ? 'text-success' : 'text-danger'); ?>"></i>	
					</td>
					<td><?php echo e($product->category ? $product->category->title : ""); ?></td>
					<td><?php echo e($product->brand ? $product->brand->title : ""); ?></td>
				</tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
		</tbody>
	</table>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	(function($){
        $(document).ready(function(){
	        $('#table').DataTable({
	        	
	        	//устанавливает свойства инициализации определения столбца
	        	// https://datatables.net/reference/option/columns.className - присваиваем класс для 3 столбца
	        	"columnDefs": [
    				{ className: "price", "targets": [ 3 ] } 
  				],
  				// drawCallback, функция, которая вызывается каждый раз, когда DataTables выполняет отрисовку.
	        	 "drawCallback": function( settings ) {
        			$( ".product-title" )
			  		.on( "mouseenter", function() {
			  			$(this).find('.product-edit').addClass('visible');
					})
					.on( "mouseleave", function() {
			  			$(this).find('.product-edit').removeClass('visible');
					});
    			}
	        });
//https://datatables.net/forums/discussion/48593/how-do-i-make-td-element-editable-on-double-click
	        $('#table tbody').on( 'dblclick', '.price', function () {
				console.log($( this ).text());
				newInput(this);
			} );


			function newInput(elm) { 
               var value = $(elm).text();
               $(elm).empty();
 
               $("<input>")
                   .attr('type', 'text')
                   .val(value)
                   .blur(function () {
                       closeInput(elm);
                   })
                   .appendTo($(elm))
                   .focus();
           }
            
            function closeInput(elm) {
               var value = $(elm).find('input').val();
               $(elm).empty().text(value);
				$.ajax({
					type: 'POST',
					url: '/admin/update-price',
					data:{
						id: $(elm).closest('tr').data('id'),
						newPrice: value
					},
					success: function(result){
						console.log(123);
					}
				});

           }
        });
    })(jQuery);  
</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/admin/product/index.blade.php ENDPATH**/ ?>