 

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($pageTitle); ?></h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php if(session('message')): ?>
	    <div class="alert alert-success">
	        <?php echo e(session('message')); ?>

	    </div>
	<?php endif; ?>

	<table id="table">
		<thead>
			<tr>
				<th>№</th>
				<th>Название</th>
				<th>Скидка</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $discount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($loop->iteration); ?></td>
					<td class="disc-name">
						<?php echo e($disc->title); ?>

						<div class="disc-edit">
							<a href="/admin/discount/<?php echo e($disc->id); ?>/edit" class="btn-link">Редактировать</a>
							<form action="/admin/discount/<?php echo e($disc->id); ?>" method="POST">
								<input type="hidden" name="_method" value="DELETE">
								<?php echo e(csrf_field()); ?>

								<button class="delete btn-link" style="width: 80px">Удалить</button>
							</form>
						</div>
					</td>
					<td><?php echo e($disc->percent); ?></td>
					
				</tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
		</tbody>
	</table>   
<?php $__env->stopSection(); ?> 
 
<?php $__env->startSection('js'); ?>
<script>
	(function($){
        $(document).ready(function(){
	        $('#table').DataTable({
	        	"drawCallback": function( settings ) {  
        			$( ".disc-name" )
			  		.on( "mouseenter", function() {
			  			$(this).find('.disc-edit').addClass('visible');
					})
					.on( "mouseleave", function() {
			  			$(this).find('.disc-edit').removeClass('visible');
					});
    			}
	        });
        });
    })(jQuery);  
</script>

<?php $__env->stopSection(); ?>

	
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/admin/discount/index.blade.php ENDPATH**/ ?>