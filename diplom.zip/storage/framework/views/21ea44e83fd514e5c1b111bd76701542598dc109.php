<?php $__env->startSection('content'); ?>

<div class="container">
    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
</div>

<!--banner-starts-->
    <div class="bnr" id="home">
        <div  id="top" class="callbacks_container">
            <ul class="rslides" id="slider4">
                <li>
                    <img src="images/home-slider/img_1.png" alt=""/>
                </li>
                <li>
                    <img src="images/home-slider/img_2.png" alt=""/>
                </li>
                <li>
                    <img src="images/home-slider/img_3.png" alt=""/>
                </li>
                 <li>
                    <img src="images/home-slider/img_4.png" alt=""/>
                </li>
                 <li>
                    <img src="images/home-slider/img_5.png" alt=""/>
                </li>
            </ul>
        </div>
        <div class="clearfix"> </div>
    </div>
    <!--banner-ends--> 

    <!--about-starts-->
    <?php if($brands): ?>
    <div class="about"> 
        <div class="container">
            <div class="about-top grid-1">
                <div class="row">
                    <div class="owl-carousel">
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="about-left">
                            <figure class="effect-bubba">
                                <a href="/brand/<?php echo e($brand->id); ?>">
                                    <img class="img-fluid" src="<?php echo e($brand->img); ?>" alt=""/>
                                    <figcaption>                                    
                                        <h2><?php echo e($brand->title); ?></h2>
                                    </figcaption>
                                </a>           
                            </figure>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <!--about-end-->
    <!--product-starts-->
    <?php if($hits): ?>
    <div id="hit-products" class="product"> 
        <div class="container">
            <div class="product-top">
                <div class="product-one">                    
                    <div class="row">
                        <?php $__currentLoopData = $hits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 product-left">
                                <div class="product-main simpleCart_shelfItem">
                                    <a href="/product/<?php echo e($hit->slug); ?>" class="mask"><img class="img-fluid zoom-img" src="<?php echo e($hit->img); ?>" alt="" /></a>
                                    <div class="product-bottom">
                                        <h3><a href="/product/<?php echo e($hit->slug); ?>"><?php echo e($hit->title); ?></a></h3>
                                        <div class="product-price">
                                             <h4>
                                                <a class="add-to-cart-link" href="#" data-id="<?php echo e($hit->id); ?>"><i class="fas fa-cart-plus"></i></a>
                                                
                                                <span class="item_price">
                                                <?php if($hit->old_price): ?>
                                                    <small><del><?php echo e($hit->old_price); ?></del></small>
                                                <?php endif; ?>
                                                <?php echo e($hit->price); ?> грн.</span>   
                                            </h4>

                                             <?php if(Auth::user()): ?> 
                                                
                                                <?php if($wishProductsProvider->contains('product_id', $hit->id)): ?>
                                                    <a href="" class="wish-list" data-user_id="<?php echo e(Auth::user()->id); ?>" data-product_id="<?php echo e($hit->id); ?>"> <i class="fa-lg fas fa-heart"></i><span class="hidden">Добавить в список желаний</span></a>
                                                <?php else: ?>
                                                    <a href="" class="wish-list" data-user_id="<?php echo e(Auth::user()->id); ?>" data-product_id="<?php echo e($hit->id); ?>"> <i class="fa-lg far fa-heart"></i><span>Добавить в список желаний</span></a> 
                                                <?php endif; ?>
                                             <?php endif; ?>   

                                            </div>
                                        </div>
                                        <?php if($hit->old_price): ?>
                                            <div class="srch">
                                                <span><?php echo e(round(($hit->old_price-$hit->price)*100/$hit->old_price, 0)); ?>%</span>
                                            </div>
                                        <?php endif; ?> 
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
                    </div>                   
                    <div class="clearfix"></div>
                </div>
            </div>                  
        </div>
    </div>
    <?php endif; ?>
    <!--product-end-->




<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    (function($){
        $(document).ready(function(){
        $(".owl-carousel").owlCarousel({
            nav:true,
            margin: 10,
            loop: true,
            responsiveClass:true,
            navText : ['<i class="fa fa-angle-left" aria-hidden="true"></i>','<i class="fa fa-angle-right" aria-hidden="true"></i>'],
            responsive:{
                0:{
                    items:2,
                    nav: false,
                },
                600:{
                    items:4,
                },
                1000:{
                    items:6,
                }
            }
        });
        });
    })(jQuery);    
</script>

<!--Slider-Starts-Here-->
    <script src="js/responsiveslides.min.js"></script>
     <script>
        $(function () {
          $("#slider4").responsiveSlides({
            auto: true, // Boolean: Animate automatically, true or false
            pager: true, // Boolean: Show pager, true or false
            speed: 500, // Integer: Speed of the transition, in milliseconds
            namespace: "callbacks"
          });
    
        });
      </script>
<!--End-slider-script-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/web/page/home.blade.php ENDPATH**/ ?>