<?php $__env->startSection('content'); ?>
<div class="container">
	<?php if(session('message')): ?>
	    <div class="alert alert-success">
	        <?php echo e(session('message')); ?>

	    </div>
	<?php endif; ?>
  
	 <div class="products"> 
    <div class="container">
      <div class="products-top">
        <div class="row">
          <div class="col-md-9 products-left">
          <div class="product-one row">
            <?php if($wishlist->isEmpty()): ?>
              <div class="empty-wishlist">
                <p>Список пуст. <a href="/#hit-products">Обратите внимание на хиты продаж</a></p>
              </div>
            <?php else: ?>
            <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-4 product-left p-left">
                <div class="product-main simpleCart_shelfItem">

                  <button type="button" class="close delete-wish-product" data-user_id="<?php echo e(Auth::user()->id); ?>" data-product_id="<?php echo e($wish->product->id); ?>" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                  </button>

                  <a href="/product/<?php echo e($wish->product->slug); ?>" class="mask"><img class="img-fluid zoom-img" src="<?php echo e($wish->product->img); ?>" alt="" /></a>
                  <div class="product-bottom">
                    <h3><a href="/product/<?php echo e($wish->product->slug); ?>"><?php echo e($wish->product->title); ?></a></h3>

                    <h4>
                      <span class=" item_price">
                      <?php if($wish->product->old_price): ?>
                          <small><del><?php echo e($wish->product->old_price); ?></del></small>
                      <?php endif; ?>
                      <?php echo e($wish->product->price); ?> грн.</span> 
                    </h4>
                  </div>
                  <?php if($wish->product->old_price): ?>
                      <div class="srch">
                          <span><?php echo e(round(($wish->product->old_price - $wish->product->price) *100 / $wish->product->old_price, 0)); ?>%</span>
                      </div>
                  <?php endif; ?> 
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            <div class="clearfix"></div>            
          </div>
        </div>  
        <div class="clearfix"></div>
        </div>
      </div>
     <div class="d-flex justify-content-center"><?php echo e($wishlist->links('vendor.pagination.bootstrap-4')); ?> </div>
  </div>	
</div>		

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	(function($){
        $(document).ready(function(){
	        
        });
    })(jQuery);  
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/web/profile/wishlist.blade.php ENDPATH**/ ?>