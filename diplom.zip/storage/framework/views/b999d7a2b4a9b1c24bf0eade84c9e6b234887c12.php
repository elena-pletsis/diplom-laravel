 

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($pageTitle); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php if(session('message')): ?>
	    <div class="alert alert-success">
	        <?php echo e(session('message')); ?>

	    </div>
	<?php endif; ?>
	<table id="table">
		<thead>
			<tr>
				<th>Заказ</th>
				<th>Имя фамилия пользователя</th>
				<th>Email</th>
				<th>Номер телефона</th>
				<th>Адрес</th>
				<th>Статус заказа</th>
				<th>Валюта</th>
				<th>Примечание</th>
				<th>Общая сумма</th>
				<th>Сумма к уплате</th>
				<th>Создан</th>
				<th>Обновлен</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td>
						<a href="/admin/order/<?php echo e($order->id); ?>"><?php echo e($order->id); ?></a></td>					
					<td>
						
						<?php if($order->user_id): ?>
						<a href="/admin/order/user/<?php echo e($order->user_id); ?>"><?php echo e($order->full_name); ?></a>
						<?php else: ?>
						<?php echo e($order->full_name); ?>

						<?php endif; ?>
					</td>
					<td>
						<?php if($order->user_id): ?>
						<a href="/admin/order/user/<?php echo e($order->user_id); ?>"><?php echo e($order->email); ?></a>
						<?php else: ?>
						<?php echo e($order->email); ?>

						<?php endif; ?>
					</td>
					<td><?php echo e($order->phone); ?></td>
					<td><?php echo e($order->address); ?></td>
					<td><?php echo e($order->status->name); ?></td>
					<td><?php echo e($order->currency); ?></td>
					<td><?php echo e($order->note); ?></td>
					<td><?php echo e($order->total_sum); ?></td>
					<td><?php echo e($order->sum_to_pay); ?></td>
					<td><?php echo e($order->created_at); ?></td>	
					<td><?php echo e($order->updated_at); ?></td>				
				</tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
		</tbody>
	</table>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	(function($){
        $(document).ready(function(){
	        $('#table').DataTable({








	        });
        });
    })(jQuery);  
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/admin/order/index.blade.php ENDPATH**/ ?>