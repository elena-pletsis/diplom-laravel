 

<?php $__env->startSection('title', $pageTitle); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($pageTitle); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php if(session('message')): ?>
		    <div class="alert alert-success">
		        <?php echo e(session('message')); ?>

		    </div>
	<?php endif; ?>
	<form action="/admin/users/<?php echo e($user->id); ?>" method="POST">
		<input type="hidden" name="_method" value="PUT">
		<?php echo e(csrf_field()); ?>

		<div class="form-group">
			<label for="fname">Имя:</label>
			<input type="text" class="form-control" id="fname" name="fname" value="<?php echo e($user->first_name); ?>">
		</div>
		<div class="form-group">
			<label for="lname">Фамилия:</label>
			<input type="text" class="form-control" id="lname" name="lname" value="<?php echo e($user->last_name); ?>">
		</div>
		<div class="form-group">
			<label for="email">Email:</label>
			<input type="text" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>">
		</div>
		<div class="form-group">
			<label for="address">Адрес:</label>
			<input type="text" class="form-control" id="address" name="address" value="<?php echo e($user->address); ?>">
		</div>
		<div class="form-group">
			<label for="phone">Номер телефона:</label>
			<input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($user->phone); ?>">
		</div>

		<div class="form-group">
			<label for="new_password">Новый пароль (если необходимо):</label>
			<input type="password" class="form-control" id="new_password" name="new_password">
		</div>
		<div class="form-group">
			<label for="roles">Роли:</label>
			<select class="form-control" id="roles" name="roles[]" multiple>
				<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option 
					<?php echo e((($userRoles->contains('id', $role->id)) ? 'selected' : '')); ?> 
					value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<div class="checkbox">
 			<label><input type="checkbox" name="club_member" value="<?php echo e($user->club_member); ?>" <?php echo e($user->club_member == 1 ? 'checked' : ''); ?>>Член клуба "Мокрый нос"</label>
 		</div>
		<button class="btn btn-primary">Сохранить</button>
	</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	$(document).ready( function () {
    	$('#roles').select2();
	} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>