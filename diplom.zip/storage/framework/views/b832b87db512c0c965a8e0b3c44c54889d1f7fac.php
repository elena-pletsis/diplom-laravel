<h1>Заказ № <?php echo e($order->id); ?></h1>
<?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="row product">
    <div class="col-3">
        <img src="<?php echo $message->embed(public_path().$product['img']); ?>" alt="" class="img-fluid">
    </div>
    <div class="col-8">
       <h4><?php echo e($product['title']); ?></h4> 
       <?php echo e($product['qty']); ?> * <?php echo e($product['price']); ?> =  <?php echo e($product['qty'] * $product['price']); ?>

    </div>    
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/emails/orderAdmin.blade.php ENDPATH**/ ?>