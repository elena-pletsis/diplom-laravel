<?php $__env->startSection('content'); ?>
    <!--products-starts-->
    
  <div class="products"> 
    <div class="container">
      <div class="products-top">
        <div class="row">          
          <div class="col-md-12 products-left">
            <div class="row brand-description">
              <h3 class="text-center"><?php echo e($choosedBrand->title); ?></h3>
              <span><?php echo e($choosedBrand->description); ?></span>
            </div>
            <div class="product-one row">
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 product-left p-left">
                  <div class="product-main simpleCart_shelfItem">
                    <a href="/product/<?php echo e($product->slug); ?>" class="mask"><img class="img-fluid zoom-img" src="<?php echo e($product->img); ?>" alt="" /></a>
                    <div class="product-bottom">
                      <h3><a href="/product/<?php echo e($product->slug); ?>"><?php echo e($product->title); ?></a></h3>
                      <h4>
                        <a class="add-to-cart-link" href="#" data-id="<?php echo e($product->id); ?>"><i class="fas fa-cart-plus"></i></a>
                        <span class="item_price">
                          <?php if($product->old_price): ?>
                            <small><del><?php echo e($product->old_price); ?></del></small>
                        <?php endif; ?>
                        <?php echo e($product->price); ?> грн.</span>
                      </h4>
                      <?php if(Auth::user()): ?> 
                        
                          <?php if($wishProductsProvider->contains('product_id', $product->id)): ?>
                              <a href="" class="wish-list" data-user_id="<?php echo e(Auth::user()->id); ?>" data-product_id="<?php echo e($product->id); ?>"> <i class="fa-lg fas fa-heart"></i><span class="hidden">Добавить в список желаний</span></a> 
                          <?php else: ?>
                              <a href="" class="wish-list" data-user_id="<?php echo e(Auth::user()->id); ?>" data-product_id="<?php echo e($product->id); ?>"> <i class="fa-lg far fa-heart"></i><span>Добавить в список желаний</span></a> 
                          <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <?php if($product->old_price): ?>
                        <div class="srch">
                            <span><?php echo e(round(($product->old_price-$product->price)*100/$product->old_price, 0)); ?>%</span>
                        </div>
                    <?php endif; ?> 
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <div class="clearfix"></div>            
            </div>
          </div>
        </div>
      </div>
    </div>
     <div class="d-flex justify-content-center"><?php echo e($products->links('vendor.pagination.bootstrap-4')); ?> </div>
  </div>
  <!--product-end-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OSPanel\domains\diplom\resources\views/web/page/brand.blade.php ENDPATH**/ ?>