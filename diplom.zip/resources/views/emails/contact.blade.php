Получено новое письмо от : {{ $user_full_name }}
<p>
ФИО: {{ $user_full_name }}
</p>
<p>
Номер телефона: {{ $user_phone }}
</p>
<p>
Email: {{ $user_email }}
</p>
<p>
Текст сообщения: {{ $user_message }}
</p>